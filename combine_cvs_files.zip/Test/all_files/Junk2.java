public class Junk2 {
  int x = 5;

  public static void main(String[] args) {
    Junk2 myObj = new Junk2();
    System.out.println(myObj.x);
  }
}